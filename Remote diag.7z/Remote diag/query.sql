WITH dataset AS (SELECT vins[ordinal(1)] AS vin 
                   , LAST_VALUE (Eventtime) OVER (PARTITION BY vins[ordinal(1)] ORDER BY Eventtime ASC  ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) AS Eventtime
                   , LAST_VALUE (data) OVER (PARTITION BY vins[ordinal(1)] ORDER BY Eventtime ASC  ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) AS data
                 FROM `irn-72461-ope-af.eventarchiver_dataset_aza.event_archive`
                 WHERE $__timeFilter(eventtime)
                   AND resourceType = 'VEHICLESTATE'
                   AND data LIKE '%202852%'),
    data2852 AS (SELECT data,vin
                  , any_value(Eventtime) AS time
                  , any_value((SELECT a 
                               FROM UNNEST(JSON_QUERY_ARRAY(data, '$.states')) a 
                               WHERE JSON_VALUE(a, '$.category') = 'TECHNICAL_PRODUCT'
                                 AND JSON_VALUE(a, '$.type') = '202852')) AS state
                FROM dataset
                GROUP BY 1,2),
    base AS (SELECT vin,data
              , time AS timeLog
              , JSON_VALUE(state, '$.requestedState') AS requestedState
              , JSON_VALUE(state, '$.currentState') AS currentState
              , TIMESTAMP(SUBSTR(JSON_VALUE(state, '$.lastModificationTimestamp'),1, 23)) AS lastModificationTimestamp
              , TIMESTAMP(SUBSTR(JSON_VALUE(state, '$.requestTimestamp'),1, 23)) AS requestTimestamp
              , JSON_VALUE(state, '$.type') AS type
             FROM data2852
             GROUP BY 1,2,3,4,5,6,7,8
             )
SELECT 

 TIMESTAMP_TRUNC(coalesce(lastModificationTimestamp, requestTimestamp, timeLog), HOUR ) AS time
  , currentState
  , lastModificationTimestamp
  , requestTimestamp
  , TIMESTAMP_DIFF(lastModificationTimestamp, requestTimestamp, MILLISECOND) AS time_diff_in_milliseconds
  , data
FROM
    base
WHERE requestedState = 'ACTIVATED' AND currentState= 'TO_BE_RETRIED' AND type= '202852'
GROUP BY 1, 2, 3, 4, 5, 6
ORDER BY 1 ASC